package org.openjfx;

public class InternetPackage {
    private static int count = 1;
    private int id;
    private String firstName;
    private String lastName;
    private String address;
    private int speed;
    private String band;
    private int duration;

    public InternetPackage(String firstName, String lastName,String address, int speed, String band, int duration) {
        this.id = count++;
        this.firstName = firstName;
        this.address = address;
        this.lastName = lastName;
        this.speed = speed;
        this.band = band;
        this.duration = duration;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public String getBand() {
        return band;
    }

    public void setBand(String band) {
        this.band = band;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        InternetPackage.count = count;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "InternetPackage{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", address='" + address + '\'' +
                ", speed=" + speed +
                ", band='" + band + '\'' +
                ", duration=" + duration +
                '}';
    }
}
