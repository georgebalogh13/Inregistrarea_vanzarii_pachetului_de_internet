package org.openjfx;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


/**
 * JavaFX App
 */
public class App extends Application {

    @Override
    public void start(Stage stage) {
        stage.setWidth(900);
        stage.setHeight(500);
        SplitPane splitPane = new SplitPane();

        VBox left  = new VBox(new Label());
        left.setPadding(new Insets(20));
        left.setMaxWidth(400);
        VBox right = new VBox(new Label());
        right.setMinWidth(500);
        TextField firstName = new TextField();
        firstName.setPromptText("First name");
        TextField lastName = new TextField();
        lastName.setPromptText("Last name");
        left.getChildren().add(firstName);
        left.getChildren().add(lastName);

        TextField address = new TextField();
        address.setPromptText("Address");
        left.getChildren().add(address);
        left.getChildren().add(new Label());// empty line

        Label speedLabel = new Label("Speed (mb/s):");
        left.getChildren().add(speedLabel);
        int[] speedValue = {0};

        Button s1 = new Button("2");
        Button s5 = new Button("5");
        Button s10 = new Button("10");
        Button s20 = new Button("20");
        Button s50 = new Button("50");
        Button s100 = new Button("100");
        HBox speedBox = new HBox();
        speedBox.getChildren().addAll(s1, s5, s10, s20, s50, s100);
        left.getChildren().add(speedBox);

        Button[] btns = {s1, s5, s10, s20, s50, s100};
        for (int i = 0; i < btns.length; i++) {
            btns[i].setOnAction(e -> {
                speedValue[0] = Integer.parseInt(  ((Button) e.getSource()).getText()   );
                System.out.println(speedValue[0]);
            });
        }

        Label bandwidth = new Label("Bandwidth:");
        left.getChildren().add(bandwidth);

        Button t1 = new Button("1");
        Button t5 = new Button("5");
        Button t10 = new Button("10");
        Button t100 = new Button("100");
        Button flat = new Button("Flat");

        HBox bandBox = new HBox();
        bandBox.getChildren().addAll(t1, t5, t10, t100, flat);
        left.getChildren().add(bandBox);
        String[] bandValue = {"GB"};
        Button[] bandBtns = {t1, t5, t10, t100, flat};
        for (int i = 0; i < bandBtns.length; i++) {
            bandBtns[i].setOnAction(e -> {
                bandValue[0] =  ((Button) e.getSource()).getText();
                System.out.println(bandValue[0]);
            });
        }

        Label duration = new Label("Duration ( Years )");
        left.getChildren().add(duration);

        Button y1 = new Button("1");
        Button y2 = new Button("2");

        HBox yearBox = new HBox();
        yearBox.getChildren().addAll(y1,y2);
        int[] yearValue = {0};
        Button[] yearsButtons = {y1,y2};
        for (int i = 0; i < yearsButtons.length; i++) {
            yearsButtons[i].setOnAction(e -> {
                yearValue[0] = Integer.parseInt(  ((Button) e.getSource()).getText()   );
                System.out.println(yearValue[0]);
            });
        }

        left.getChildren().add(yearBox);


        HBox actions = new HBox();
        Button save = new Button("Save package");

        InternetPackage ip1 = new InternetPackage("Dan", "Badea", "Bucuresti", 10, "2", 1);
        InternetPackage ip2 = new InternetPackage("Ion", "Marian","Sibiu", 100, "Flat", 2);


        TableView<InternetPackage> tableView = new TableView<InternetPackage>();
        tableView.getItems().add(ip1);
        tableView.getItems().add(ip2);
        TableColumn<InternetPackage, String> c0 = new TableColumn<>("ID");
        c0.setCellValueFactory(new PropertyValueFactory<>("id"));
        TableColumn<InternetPackage, String> c1 = new TableColumn<>("First Name");
        c1.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        TableColumn<InternetPackage, String> c2 = new TableColumn<>("Last Name");
        c2.setCellValueFactory(new PropertyValueFactory<>("lastName"));

        TableColumn<InternetPackage, String> c3 = new TableColumn<>("Address");
        c3.setCellValueFactory(new PropertyValueFactory<>("address"));

        TableColumn<InternetPackage, String> c4 = new TableColumn<>("Speed");
        c4.setCellValueFactory(new PropertyValueFactory<>("speed"));

        TableColumn<InternetPackage, String> c5 = new TableColumn<>("Bandwidth");
        c5.setCellValueFactory(new PropertyValueFactory<>("band"));

        TableColumn<InternetPackage, String> c6 = new TableColumn<>("Duration");
        c6.setCellValueFactory(new PropertyValueFactory<>("duration"));

        tableView.getColumns().addAll(c0,c1, c2 , c3 ,c4, c5, c6);

        VBox listBox = new VBox(tableView);
        right.getChildren().add(listBox);


        save.setOnAction(e -> {
            String fn = firstName.getText();
            String ln = lastName.getText();
            String addressText = address.getText();

            InternetPackage internetPackage = new InternetPackage(fn, ln,addressText, speedValue[0], bandValue[0], yearValue[0]);
            tableView.getItems().add(internetPackage);

        });




        Button clear = new Button("Clear Form");

        clear.setOnAction(e ->{
            firstName.clear();
            lastName.clear();
            address.clear();
            firstName.setPromptText("First Name");
            lastName.setPromptText("Last name");
            address.setPromptText("Address");
            System.out.println("cleared");
        });
        Button delete = new Button("Delete Table Row");

        actions.getChildren().addAll(save, clear, delete);
        left.getChildren().add(new Label());
        left.getChildren().add(new Label());
        left.getChildren().add(actions);



        splitPane.getItems().addAll(left, right);

        Scene scene = new Scene(splitPane);

        stage.setScene(scene);
        stage.setTitle("JavaFX App");

        VBox deleteLayout = new VBox(10);
        deleteLayout.setPadding(new Insets(5, 5, 5, 50));
        deleteLayout.setStyle("-fx-background-color: BEIGE");

        Stage s = new Stage();
        Scene ss=new Scene(deleteLayout,240,200);
        s.setScene(ss);
        s.setTitle("Delete row");

        Label eid = new Label("Enter id");
        TextField id = new TextField();
        deleteLayout.getChildren().addAll(eid, id);

        Button dbu = new Button("Delete");
        deleteLayout.getChildren().add(dbu);
        delete.setOnAction(e ->{
            s.show();
            dbu.setOnAction(e1 -> {
                String text = id.getText();
                int idInt = Integer.parseInt(text);
                InternetPackage ip = null;
                for (int i = 0; i < tableView.getItems().size(); i++) {
                   if(tableView.getItems().get(i).getId()== idInt){
                       ip = tableView.getItems().get(i);
                   }
                }
                if(ip!=null){
                    tableView.getItems().remove(ip);
                }else{
                    System.out.println("No internet package available with that id");
                }
            });
        });

        stage.show();

    }

    public static void main(String[] args) {
        launch();
    }

}